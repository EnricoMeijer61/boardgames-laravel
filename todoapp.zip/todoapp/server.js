var express  = require('express'),
    path     = require('path'),
    bodyParser = require('body-parser'),
    app = express(),
    expressValidator = require('express-validator');


/*Set EJS template Engine*/
app.set('views','./views');
app.set('view engine','ejs');

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true })); //support x-www-form-urlencoded
app.use(bodyParser.json());
app.use(expressValidator());

/*MySql connection*/
var connection  = require('express-myconnection'),
    mysql = require('mysql');

app.use(

    connection(mysql,{
        host     : 'localhost',
        user     : 'root',
        password : 'root11',
        port : 3309,
        database : 'todoapp',
        debug    : false //set true if you wanna see debug logger
    },'request')

);

app.get('/~s1129258/P2_NodeJS_Opdracht/752/todoapp/',function(req,res){
    res.send('Welkom, in deze map staat mijn todo app. ga naar /todo.');
});


//RESTful route
var router = express.Router();


/*------------------------------------------------------
*  This is router middleware,invoked everytime
--------------------------------------------------------*/
router.use(function(req, res, next) {
    console.log(req.method, req.url);
    next();
});

var curut = router.route('/~s1129258/P2_NodeJS_Opdracht/752/todoapp/todo');


//show the CRUD interface | GET
curut.get(function(req,res,next){


    req.getConnection(function(err,conn){

        if (err) return next("Cannot Connect");

        var query = conn.query('SELECT * FROM tasks WHERE status = 1' ,function(err,rows){

            if(err){
                console.log(err);
                return next("Mysql error, check your query");
            }

            res.render('task',{title:"TodoApp",data:rows});

        });

    });

});

//get 2
curut.get(function(req,res,next){


    req.getConnection(function(err,conn){

        if (err) return next("Cannot Connect");

        var query = conn.query('SELECT * FROM tasks WHERE status = 2' ,function(err,rows){

            if(err){
                console.log(err);
                return next("Mysql error, check your query");
            }

            res.render('task2',{title2:"TodoApp",data2:rows});

        });

    });

});


//post data to DB | POST
curut.post(function(req,res,next){

    //validation
    req.assert('name','Name is required').notEmpty();


    var errors = req.validationErrors();
    if(errors){
        res.status(422).json(errors);
        return;
    }

    //get data
    var data = {
        name:req.body.name,
        description:req.body.description

    };


    //inserting into mysql
    req.getConnection(function (err, conn){

        if (err) return next("Cannot Connect");

        var query = conn.query("INSERT INTO tasks set ? ",data, function(err, rows){

            if(err){
                console.log(err);
                return next("Mysql error, check your query");
            }

            res.sendStatus(200);

        });

    });

});


//now for Single route (GET,DELETE,PUT)
var curut2 = router.route('/~s1129258/P2_NodeJS_Opdracht/752/todoapp/todo/:task_id');

curut2.all(function(req,res,next){
    console.log("route");
    console.log(req.params);
    next();
});

//get data to update
curut2.get(function(req,res,next){

    var task_id = req.params.task_id;

    req.getConnection(function(err,conn){

        if (err) return next("Cannot Connect");

        var query = conn.query("SELECT * FROM tasks WHERE task_id = ? ",[task_id],function(err,rows){

            if(err){
                console.log(err);
                return next("Mysql error, check your query");
            }

            //if task not found
            if(rows.length < 1)
                return res.send("task Not found");

            res.render('edit',{title:"Edit task",data:rows});
        });

    });

});

//update data
curut2.put(function(req,res,next){
    var task_id = req.params.task_id;

    //validation
    req.assert('name','Name is required').notEmpty();


    var errors = req.validationErrors();
    if(errors){
        res.status(422).json(errors);
        return;
    }

    //get data
    var data = {
        name:req.body.name,
        description:req.body.description

    };

    //inserting into mysql
    req.getConnection(function (err, conn){

        if (err) return next("Cannot Connect");

        var query = conn.query("UPDATE tasks set ? WHERE task_id = ? ",[data,task_id], function(err, rows){

            if(err){
                console.log(err);
                return next("Mysql error, check your query");
            }

            res.sendStatus(200);

        });

    });

});

//delete data
curut2.delete(function(req,res,next){

    var task_id = req.params.task_id;

    req.getConnection(function (err, conn) {

        if (err) return next("Cannot Connect");

        var query = conn.query("UPDATE tasks set status = 2  WHERE task_id = ?",[task_id], function(err, rows){

            if(err){
                console.log(err);
                return next("Mysql error, check your query");
            }

            res.sendStatus(200);

        });
        //console.log(query.sql);

    });
});

app.use('/', router);

//start Server
var server = app.listen(4000,function(){

    console.log("Listening to port %s",server.address().port);

});
